plot module
===========

.. automodule:: plot
    :members:
    :undoc-members:
    :show-inheritance:
