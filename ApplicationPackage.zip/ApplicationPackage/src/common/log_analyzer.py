# -*- coding: utf-8 -*-
"""
Created on Thu Jul 23 19:04:21 2020

@author: PC
"""

import os, sys
import pandas as pd
import codecs
import glob
#import datetime
import common.console as csl

from matplotlib import pyplot as plt
from matplotlib.ticker import MaxNLocator
from datetime import datetime
import matplotlib.dates as mdates
from PIL import Image

import config
import common.logger as logger
import common.feature_value as fv
import common.timechart as timechart

FIG_SIZE_X = 10
FIG_SIZE_Y = 10

IMAGE_SHOW_ENABLE = False
#IMAGE_SHOW_ENABLE = True


def show_loginfo(df):
    logger.debug_msg("----- Function Start -----")
    csl.stdout_info("---------次元数-----------")
    csl.stdout_info(df.shape)

    csl.stdout_info("----------列名一覧----------")
    csl.stdout_info(df.columns)

    csl.stdout_info("----------object/int64/float64/bool/datetime64/timedelta[ns]/category----------")
    csl.stdout_info(df.dtypes)

    csl.stdout_info("----------要約情報---------")
    csl.stdout_infotdout_info(df.info)

    csl.stdout_info("----------先頭数行----------")
    csl.stdout_info(df.head)

    csl.stdout_info("----------末尾数行----------")
    csl.stdout_infotdout_infotdout_infotdout_info(df.tail)

    csl.stdout_info("--------------------")
    csl.stdout_infotdout_infotdout_infotdout_info(df.index)

    csl.stdout_info("---------基本統計量-----------")
    csl.stdout_infotdout_info(df.describe())

    csl.stdout_infotdout_infotdout_info("---------ログレベル-----------")
    csl.stdout_info(df['levelname'])

    csl.stdout_info("---------ログレベル集計-----------")
    csl.stdout_info(df["levelname"].value_counts())
    logger.debug_msg("----- Function End -----")


def detection(start_time=0, end_time=0):
    logger.debug_msg("----- Function Start -----")
    logger.trace_msg("APP->>Log Analyzer:Analyze")
    start = datetime.now()
    global setting
    setting = pd.read_csv(config.log_analyzer_ini_file, header=0, sep=",")
    lensetting = len(setting)

    for i in range(lensetting):
        logger.app_logger.info(setting.iloc[i, 0])
        if setting.iloc[i, 0].startswith('#'):continue  # コメントアウト
        get_param(i, start_time, end_time)
        preparation(i)
        total(i)
        circlegraph(i)
        timecount(i)
        bargraph(i)
        timesumtotal(i)
        linegraph(i)
        linegraphall(i)
        allgraph(i)
        fv.get_feature_value(g_data_dir, "timecount.csv", g_logwording1, g_logwording2, g_logwording3, g_logwording4, g_logwording5)

    timechart.logging_md("Log Analyzer", start, datetime.now())
    logger.trace_msg("Log Analyzer-->>APP:Success")
    logger.debug_msg("----- Function End -----")


def get_param(csvindex, start_time=0, end_time=0):
    logger.debug_msg("----- Function Start -----")
    global g_logitem
    global g_logfiles
    global g_freqtime
    global g_timecolumnnum
    global g_logtypecolumnnum
    global g_starttimeY
    global g_starttimeH
    global g_endtimeY
    global g_endtimeH
    global g_separator
    global g_logwording1
    global g_logwording2
    global g_logwording3
    global g_logwording4
    global g_logwording5
    global g_timecolumnnum1
    global g_timecolumnnum2
    global timecolumn

    g_logitem = setting.iloc[csvindex, 0]
    g_logfiles = setting.iloc[csvindex, 1]
    g_freqtime = str(setting.iloc[csvindex, 2])
    g_timecolumnnum = setting.iloc[csvindex, 3]
    g_logtypecolumnnum = setting.iloc[csvindex, 4]

    if start_time == 0:
        g_starttimeY = setting.iloc[csvindex, 5]
        g_starttimeH = setting.iloc[csvindex, 6]
        g_endtimeY = setting.iloc[csvindex, 7]
        g_endtimeH = setting.iloc[csvindex, 8]
    else:
        g_starttimeY = start_time.strftime('%Y/%m/%d')
        g_starttimeH = start_time.strftime('%H:%M:%S.%f')
        g_endtimeY = end_time.strftime('%Y/%m/%d')
        g_endtimeH = end_time.strftime('%H:%M:%S.%f')

    g_separatorsetting = setting.iloc[csvindex, 9]
    if g_separatorsetting == "s":g_separator = " "
    elif g_separatorsetting == " ":g_separator = " "
    elif g_separatorsetting == "c":g_separator = ","
    elif g_separatorsetting == ",":g_separator = ","
    elif g_separatorsetting == "t":g_separator = "    "  # 動作未確認
    elif g_separatorsetting == "    ":g_separator = "   "  # 動作未確認
    else:g_separator = ","

    g_logwording1 = setting.iloc[csvindex, 10]
    g_logwording2 = setting.iloc[csvindex, 11]
    g_logwording3 = setting.iloc[csvindex, 12]
    g_logwording4 = setting.iloc[csvindex, 13]
    g_logwording5 = setting.iloc[csvindex, 14]

    if not type(g_logwording1) is str:g_logwording1 = ""
    if not type(g_logwording2) is str:g_logwording2 = ""
    if not type(g_logwording3) is str:g_logwording3 = ""
    if not type(g_logwording4) is str:g_logwording4 = ""
    if not type(g_logwording5) is str:g_logwording5 = ""

    if "-" in str(g_timecolumnnum):
        g_timecolumnnum1 = int(str(g_timecolumnnum).split("-")[0])
        g_timecolumnnum2 = int(str(g_timecolumnnum).split("-")[1])
        timecolumn = int(max(g_timecolumnnum1, g_timecolumnnum2))
    else:
        g_timecolumnnum1 = -1
        g_timecolumnnum2 = -1
        timecolumn = int(g_timecolumnnum)

    logger.debug_msg(g_logitem)
    logger.debug_msg(g_logfiles)
    logger.debug_msg(g_freqtime)
    logger.debug_msg(g_timecolumnnum)
    logger.debug_msg(g_logtypecolumnnum)
    logger.debug_msg(g_timecolumnnum1)
    logger.debug_msg(g_timecolumnnum2)
    logger.debug_msg(timecolumn)
    logger.debug_msg(g_starttimeY)
    logger.debug_msg(g_starttimeH)
    logger.debug_msg(g_endtimeY)
    logger.debug_msg(g_endtimeH)
    logger.debug_msg(g_separator)
    logger.debug_msg(g_logwording1)
    logger.debug_msg(g_logwording2)
    logger.debug_msg(g_logwording3)
    logger.debug_msg(g_logwording4)
    logger.debug_msg(g_logwording5)

    global g_data_dir
    g_data_dir = config.log_analyzer_out_dir + str(datetime.now().strftime('%Y%m%d')) + "_" + str(datetime.now().strftime('%H%M%S')) + "_" + g_logitem + "/"
    if not os.path.exists(g_data_dir): os.mkdir(g_data_dir)
    logger.debug_msg("----- Function End -----")


def preparation(csvindex):
    logger.debug_msg("----- Function Start -----")
    logger.app_logger.info("前処理")
    logtmp0 = g_data_dir + "log_concat.log"
    logtmp = g_data_dir + "preparation.log"

    files = glob.glob(g_logfiles)
    if not files:
        logger.error_msg("解析ログファイルが見つかりません:" + g_logfiles)
        sys.exit()  # 本当は終了してたくない

    with open(logtmp0, "wb") as f_new:
        for f in files:
            logger.app_logger.info(f)
            with open(f, "rb") as f_org:
                f_new.write(f_org.read())

    with open(logtmp0, encoding="utf-8") as f:
        lines = f.readlines()
        s_lines = [line.strip() for line in lines]
        logtmpfile = open(logtmp, "w", encoding="utf-8", newline="\n")
        for line in s_lines:
            if len(line) < 6: #時分秒(hhmmss)の最低限の桁数
                logger.error_msg("時分秒(hhmmss)の最低限の桁数異常")
                continue

            logtypecolumn = int(g_logtypecolumnnum)
            checkcolumn = max(timecolumn, logtypecolumn)

            if len(line.split(g_separator)) - 1 < checkcolumn:
                logger.error_msg("checkcolumn異常")
                continue

            # ログ文言
            if g_logwording1 in line.split(g_separator)[logtypecolumn]:
                line = line.replace(line.split(g_separator)[logtypecolumn], g_logwording1)
            elif g_logwording2 in line.split(g_separator)[logtypecolumn]:
                line = line.replace(line.split(g_separator)[logtypecolumn], g_logwording2)
            elif g_logwording3 in line.split(g_separator)[logtypecolumn]:
                line = line.replace(line.split(g_separator)[logtypecolumn], g_logwording3)
            elif g_logwording4 in line.split(g_separator)[logtypecolumn]:
                line = line.replace(line.split(g_separator)[logtypecolumn], g_logwording4)
            elif g_logwording5 in line.split(g_separator)[logtypecolumn]:
                line = line.replace(line.split(g_separator)[logtypecolumn], g_logwording5)

            #日付フォーマットに変換できなければ異常
            if "-" in str(g_timecolumnnum):
                # 年月日
                try:
                    if "/" in line.split(g_separator)[g_timecolumnnum1]:
                        datetime.strptime(line.split(g_separator)[g_timecolumnnum1], "%Y/%m/%d")
                    elif "-" in line.split(g_separator)[g_timecolumnnum1]:
                        datetime.strptime(line.split(g_separator)[g_timecolumnnum1], "%Y-%m-%d")
                    else:
                        datetime.strptime(line.split(g_separator)[g_timecolumnnum1], "%Y%m%d")
                except ValueError:
                    type, value, traceback = sys.exc_info()
                    logger.error_msg('Except:%s<%s>%s', type, value, traceback)
                    logger.error_msg("年月日フォーマット(YMD-hms分割)変換異常")
                    continue

                # 時分秒
                try:
                    if ("." in line.split(g_separator)[timecolumn]) or ("," in line.split(g_separator)[timecolumn]):  # ミリ秒削除(,ミリ秒対策含む)
                        posn = line.split(g_separator)[g_timecolumnnum2].rfind('.')
                        if posn == -1:posn = line.split(g_separator)[g_timecolumnnum2].rfind(',')
                        temp_time = line.split(g_separator)[g_timecolumnnum2][:posn]
                        line = line.replace(line.split(g_separator)[g_timecolumnnum2], temp_time)
                        logger.app_logger.info("ミリ秒削除")

                    datetime.strptime(line.split(g_separator)[g_timecolumnnum2], "%H:%M:%S")
                    loggingtime = line.split(g_separator)[g_timecolumnnum1] + " " + line.split(g_separator)[g_timecolumnnum2]
                except ValueError:
                    type, value, traceback = sys.exc_info()
                    logger.error_msg('Except:%s<%s>%s', type, value, traceback)
                    logger.error_msg("時分秒フォーマット(YMD-hms分割)変換異常")
                    continue
            else:
                # ミリ秒削除(,ミリ秒対策含む)
                try:
                    if ("." in line.split(g_separator)[timecolumn]) or ("," in line.split(g_separator)[timecolumn]):
                        posn = line.split(g_separator)[timecolumn].rfind('.')
                        if posn == -1:posn = line.split(g_separator)[timecolumn].rfind(',')
                        temp_time = line.split(g_separator)[timecolumn][:posn]
                        line = line.replace(line.split(g_separator)[timecolumn], temp_time)
                        logger.app_logger.info("ミリ秒削除")
                except ValueError:
                    type, value, traceback = sys.exc_info()
                    logger.error_msg('Except:%s<%s>%s', type, value, traceback)
                    logger.error_msg("時分秒フォーマット(YMD-hms分割)変換異常")
                    continue

                try:
                    if "/" in line.split(g_separator)[timecolumn]:
                        datetime.strptime(line.split(g_separator)[timecolumn], "%Y/%m/%d %H:%M:%S")
                    elif "-" in line.split(g_separator)[timecolumn]:
                        datetime.strptime(line.split(g_separator)[timecolumn], "%Y-%m-%d %H:%M:%S")
                    else:
                        datetime.strptime(line.split(g_separator)[timecolumn], "%Y%m%d %H:%M:%S")

                    loggingtime = line.split(g_separator)[timecolumn]
                except ValueError:
                    type, value, traceback = sys.exc_info()
                    logger.error_msg('Except:%s<%s>%s', type, value, traceback)
                    logger.error_msg("時分秒フォーマット(YMDhms統合)変換異常")
                    continue

            logtmpfile.write(loggingtime + ',' + line.split(g_separator)[g_logtypecolumnnum] + '\n')

        logtmpfile.close()
    logger.debug_msg("----- Function End -----")



def circlegraph(csvindex):
    logger.debug_msg("----- Function Start -----")
    logger.app_logger.info("円グラフ")
    csv = g_data_dir + "total.csv"
    data = pd.read_csv(csv, header=0, skipfooter=1, engine='python')
    get_color(data)
    pie_colors = [g_color0, g_color1, g_color2, g_color3, g_color4]
    fig1, ax1 = plt.subplots()
    ax1.pie(data['件数'], labels=g_labels, autopct='%1.1f%%', startangle=0, colors=pie_colors)
    ax1.axis('equal')
    ax1.set_title("Log Level", fontname = config.g_font)
    ax1.legend()
    if IMAGE_SHOW_ENABLE: plt.show()
    plt.close()
    plt.clf()
    fig1.savefig(g_data_dir + "circlegraph.png")
    logger.debug_msg("----- Function End -----")


def make_bargraph(csvindex, data, wording, color, index):
    logger.debug_msg("----- Function Start -----")
    bar = plt.bar(data['time'], data[wording], width = 0.4, color=color, label=wording)
    plt.xticks(rotation=90)
    plt.rcParams['figure.subplot.bottom'] = 0.20
    plt.gca().get_yaxis().set_major_locator(MaxNLocator(integer=True))
    plt.xlabel("time", fontname = config.g_font)
    plt.ylabel("num", fontname = config.g_font, rotation = 0)
    plt.title(wording, fontname = config.g_font)
    bottom, top = plt.ylim()
    if top < 1:plt.ylim(top=1.05)
    plt.ylim(bottom=0)
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(g_data_dir + "bargraph_" + wording + ".png", bbox_inches='tight')
    if IMAGE_SHOW_ENABLE: plt.show()
    plt.close()
    plt.clf()
    logger.debug_msg("----- Function End -----")



def make_linegraph(csvindex, data, wording, color, index):
    logger.debug_msg("----- Function Start -----")
    plot1 = plt.plot(data['time'], data[wording], color=color, label=wording)
    plt.xticks(rotation=90)
    plt.rcParams['figure.subplot.bottom'] = 0.20
    plt.gca().get_yaxis().set_major_locator(MaxNLocator(integer=True))
    plt.xlabel("time", fontname = config.g_font)
    plt.ylabel("num", fontname = config.g_font, rotation = 0)
    plt.title(wording, fontname = config.g_font)
    bottom, top = plt.ylim()
    if top < 1:plt.ylim(top=1.05)
    plt.ylim(bottom=0)
    plt.legend()
    plt.grid(True)
    plt.savefig(g_data_dir + "linegraph_" + wording + ".png", bbox_inches='tight')
    if IMAGE_SHOW_ENABLE: plt.show()
    plt.close()
    plt.clf()
    logger.debug_msg("----- Function End -----")


def bargraph(csvindex):
    logger.debug_msg("----- Function Start -----")
    logger.app_logger.info("棒グラフ")
    log = setting.iloc[csvindex, 0]
    plt.rcParams["figure.figsize"] = [FIG_SIZE_X, FIG_SIZE_Y]
    csv = g_data_dir + "timecount.csv"
    data = pd.read_csv(csv, header=0, skipfooter=0, engine='python')
    if not g_logwording1 == "":make_bargraph(csvindex, data, g_logwording1, config.log_analyzer_color1, 1)
    if not g_logwording2 == "":make_bargraph(csvindex, data, g_logwording2, config.log_analyzer_color2, 2)
    if not g_logwording3 == "":make_bargraph(csvindex, data, g_logwording3, config.log_analyzer_color3, 3)
    if not g_logwording4 == "":make_bargraph(csvindex, data, g_logwording4, config.log_analyzer_color4, 4)
    if not g_logwording5 == "":make_bargraph(csvindex, data, g_logwording5, config.log_analyzer_color5, 5)
    logger.debug_msg("----- Function End -----")


def get_color(data):
    logger.debug_msg("----- Function Start -----")
    global g_labels
    g_labels = data['ログ種別']
    lenlabels = len(g_labels)

    global g_color0,g_color1,g_color2,g_color3,g_color4
    g_color0 = g_color1 = g_color2 = g_color3 = g_color4 = "w"

    if 0 < lenlabels:
        if g_labels[0] == g_logwording1:g_color0 = config.log_analyzer_color1
        if g_labels[0] == g_logwording2:g_color0 = config.log_analyzer_color2
        if g_labels[0] == g_logwording3:g_color0 = config.log_analyzer_color3
        if g_labels[0] == g_logwording4:g_color0 = config.log_analyzer_color4
        if g_labels[0] == g_logwording5:g_color0 = config.log_analyzer_color5

    if 1 < lenlabels:
        if g_labels[1] == g_logwording1:g_color1 = config.log_analyzer_color1
        if g_labels[1] == g_logwording2:g_color1 = config.log_analyzer_color2
        if g_labels[1] == g_logwording3:g_color1 = config.log_analyzer_color3
        if g_labels[1] == g_logwording4:g_color1 = config.log_analyzer_color4
        if g_labels[1] == g_logwording5:g_color1 = config.log_analyzer_color5

    if 2 < lenlabels:
        if g_labels[2] == g_logwording1:g_color2 = config.log_analyzer_color1
        if g_labels[2] == g_logwording2:g_color2 = config.log_analyzer_color2
        if g_labels[2] == g_logwording3:g_color2 = config.log_analyzer_color3
        if g_labels[2] == g_logwording4:g_color2 = config.log_analyzer_color4
        if g_labels[2] == g_logwording5:g_color2 = config.log_analyzer_color5

    if 3 < lenlabels:
        if g_labels[3] == g_logwording1:g_color3 = config.log_analyzer_color1
        if g_labels[3] == g_logwording2:g_color3 = config.log_analyzer_color2
        if g_labels[3] == g_logwording3:g_color3 = config.log_analyzer_color3
        if g_labels[3] == g_logwording4:g_color3 = config.log_analyzer_color4
        if g_labels[3] == g_logwording5:g_color3 = config.log_analyzer_color5

    if 4 < lenlabels:
        if g_labels[4] == g_logwording1:g_color4 = config.log_analyzer_color1
        if g_labels[4] == g_logwording2:g_color4 = config.log_analyzer_color2
        if g_labels[4] == g_logwording3:g_color4 = config.log_analyzer_color3
        if g_labels[4] == g_logwording4:g_color4 = config.log_analyzer_color4
        if g_labels[4] == g_logwording5:g_color4 = config.log_analyzer_color5
    logger.debug_msg("----- Function End -----")


def timecount(csvindex):
    logger.debug_msg("----- Function Start -----")
 #   csl.stdout_info("###########timecount##############")
    global query1,query2,query3,query4,query5
    query1 = "type=='" + g_logwording1 + "'"
    query2 = "type=='" + g_logwording2 + "'"
    query3 = "type=='" + g_logwording3 + "'"
    query4 = "type=='" + g_logwording4 + "'"
    query5 = "type=='" + g_logwording5 + "'"

    log = g_data_dir + "preparation.log"
    file = g_data_dir + "timecount.csv"
    data = pd.read_csv(log, sep=",", header=None, usecols=[0, 1], names=("time", "type"), index_col="time", parse_dates=True)

    if not g_starttimeY == "" and not g_starttimeH == "" and not g_endtimeY == "" and not g_endtimeH == "":
        startdatetime = pd.to_datetime(g_starttimeY + " " + g_starttimeH)
        enddatetime = pd.to_datetime(g_endtimeY + " " + g_endtimeH)
#        csl.stdout_info("-------------select")
        data = data.query('time >= @startdatetime and time <= @enddatetime')
#        csl.stdout_info(data)
#    csl.stdout_info("-------------sort")
    data = data.sort_index()
#    csl.stdout_info(data)

    data1 = data.query(query1).groupby(pd.Grouper(freq=g_freqtime)).count()
    data1.columns = [g_logwording1]
    #data1.rename(index=lambda s: str(s)[11:], inplace=True)

    data2 = data.query(query2).groupby(pd.Grouper(freq=g_freqtime)).count()
    data2.columns = [g_logwording2]
    #data2.rename(index=lambda s: str(s)[11:], inplace=True)

    data3 = data.query(query3).groupby(pd.Grouper(freq=g_freqtime)).count()
    data3.columns = [g_logwording3]
    #data3.rename(index=lambda s: str(s)[11:], inplace=True)

    data4 = data.query(query4).groupby(pd.Grouper(freq=g_freqtime)).count()
    data4.columns = [g_logwording4]
    #data4.rename(index=lambda s: str(s)[11:], inplace=True)

    data5 = data.query(query5).groupby(pd.Grouper(freq=g_freqtime)).count()
    data5.columns = [g_logwording5]
    #data5.rename(index=lambda s: str(s)[11:], inplace=True)

 #   csl.stdout_info("-------------")

    data12 = data1.merge(data2, how="outer", on=['time'] )
    data123 = data12.merge(data3, how="outer", on=['time'] )
    data1234 = data123.merge(data4, how="outer", on=['time'] )
    data12345 = data1234.merge(data5, how="outer", on=['time'] )
    dataM = data12345.fillna(0).astype(int)
    dataM = dataM.sort_index()
 #   csl.stdout_info(dataM)

    fileobj1 = open(file, "w", encoding = "utf_8")
    fileobj1.write("time," + g_logwording1 + "," + g_logwording2 + "," + g_logwording3 + "," + g_logwording4 + "," + g_logwording5 +"\n")
    fileobj1.close()

    dataM.to_csv(file, mode='a', header=False)
    logger.debug_msg("----- Function End -----")


def total(csvindex):
    logger.debug_msg("----- Function Start -----")
#    csl.stdout_info("###########total##############")
    logtmp0 = g_data_dir + "log_concat.log"
    log = g_data_dir + "preparation.log"
    data = pd.read_csv(log, sep=",", header=None, usecols=[0, 1], names=("time", "type"), index_col="time", parse_dates=True)

    # 未定義時(自動試験時)
    if not g_starttimeY == "" and not g_starttimeH == "" and not g_endtimeY == "" and not g_endtimeH == "":
        startdatetime = pd.to_datetime(g_starttimeY + " " + g_starttimeH)
        enddatetime = pd.to_datetime(g_endtimeY + " " + g_endtimeH)
#        csl.stdout_info("-------------select")
        data = data.query('time >= @startdatetime and time <= @enddatetime')
#        csl.stdout_info(data)
    data = data.sort_index()
#    csl.stdout_info("-------------sort")
#    csl.stdout_info(data)

    data = data.reset_index()

#    csl.stdout_info("-------------")
#    csl.stdout_info(data)
#    csl.stdout_info("-------------2")
#    csl.stdout_info(data.groupby("type").count())
#    csl.stdout_info("-------------")
    total = data.groupby("type").count().sum()
#    csl.stdout_info(total)
#    csl.stdout_info("-------------3")

    output = g_data_dir + "total.csv"
    outputobj1 = open(output, "w", encoding = "utf_8")
    outputobj1.write("ログ種別,件数\n")
    outputobj1.close()

    data1 = data.groupby("type").count()
    data2 = data1.reset_index()

#    csl.stdout_info("data2-------------")
#    csl.stdout_info(data2)
#    csl.stdout_info("-------------")
#    csl.stdout_info(data2["type"])
    #csl.stdout_infotdout_info(data2["time"])
#    csl.stdout_info("-------------")

    data21 = data2[(data2["type"] == g_logwording1)]
    data22 = data2[(data2["type"] == g_logwording2)]
    data23 = data2[(data2["type"] == g_logwording3)]
    data24 = data2[(data2["type"] == g_logwording4)]
    data25 = data2[(data2["type"] == g_logwording5)]
#    csl.stdout_info(data25)

    data2122 = data21.merge(data22, how="outer", on=['type', 'time'])
    data212223 = data2122.merge(data23, how="outer", on=['type', 'time'])
    data21222324 = data212223.merge(data24, how="outer", on=['type', 'time'])
    data2122232425 = data21222324.merge(data25, how="outer", on=['type', 'time'])
#    csl.stdout_info("data2122232425-------------")
#    print(data2122232425.to_string(index=False))

    data2122232425.to_csv(output, mode='a', header=False, index=False)
    print(data2122232425)
    total = data2122232425["time"].sum()
#    csl.stdout_info("total-------------")
#    csl.stdout_info(total)

    outputobj2 = open(output, "a", encoding = "utf_8")
    outputobj2.write("合計," + str(total) + "\n")
    outputobj2.close()
    logger.debug_msg("----- Function End -----")


def timesumtotal(csvindex):
    logger.debug_msg("----- Function Start -----")
#    csl.stdout_info("###########timesumtotal##############")
    log = g_data_dir + "preparation.log"
    file = g_data_dir + "timesumtotal.csv"
    data = pd.read_csv(log, sep=",", header=None, usecols=[0, 1], names=("time", "type"), index_col="time", parse_dates=True)

    if not g_starttimeY == "" and not g_starttimeH == "" and not g_endtimeY == "" and not g_endtimeH == "":
        startdatetime = pd.to_datetime(g_starttimeY + " " + g_starttimeH)
        enddatetime = pd.to_datetime(g_endtimeY + " " + g_endtimeH)
#        csl.stdout_info("-------------select")
        data = data.query('time >= @startdatetime and time <= @enddatetime')
#        csl.stdout_info(data)
#    csl.stdout_info("-------------sort")
    data = data.sort_index()
#    csl.stdout_info(data)

    data1 = data.query(query1).groupby(pd.Grouper(freq=g_freqtime)).count()
    data1.columns = [g_logwording1]
    #data1.rename(index=lambda s: str(s)[11:], inplace=True)

    data2 = data.query(query2).groupby(pd.Grouper(freq=g_freqtime)).count()
    data2.columns = [g_logwording2]
    #data2.rename(index=lambda s: str(s)[11:], inplace=True)

    data3 = data.query(query3).groupby(pd.Grouper(freq=g_freqtime)).count()
    data3.columns = [g_logwording3]
    #data3.rename(index=lambda s: str(s)[11:], inplace=True)

    data4 = data.query(query4).groupby(pd.Grouper(freq=g_freqtime)).count()
    data4.columns = [g_logwording4]
    #data4.rename(index=lambda s: str(s)[11:], inplace=True)

    data5 = data.query(query5).groupby(pd.Grouper(freq=g_freqtime)).count()
    data5.columns = [g_logwording5]
    #data5.rename(index=lambda s: str(s)[11:], inplace=True)

#    csl.stdout_info("-------------")

    data12 = data1.merge(data2, how="outer", on=['time'] )
    data123 = data12.merge(data3, how="outer", on=['time'] )
    data1234 = data123.merge(data4, how="outer", on=['time'] )
    data12345 = data1234.merge(data5, how="outer", on=['time'] )
    dataM = data12345.fillna(0).astype(int)
    dataM = dataM.sort_index()
#    csl.stdout_info(dataM)

    sum1 = sum2 = sum3 = sum4 = sum5 = 0
    if not g_logwording1 == "":sum1 = int(dataM[g_logwording1].sum())
    if not g_logwording2 == "":sum2 = int(dataM[g_logwording2].sum())
    if not g_logwording3 == "":sum3 = int(dataM[g_logwording3].sum())
    if not g_logwording4 == "":sum4 = int(dataM[g_logwording4].sum())
    if not g_logwording5 == "":sum5 = int(dataM[g_logwording5].sum())

    fileobj1 = open(file, "w", encoding = "utf_8")
    fileobj1.write("time," + g_logwording1 + "," + g_logwording2 + "," + g_logwording3 + "," + g_logwording4 + "," + g_logwording5 +"\n")
    fileobj1.close()

    cumsum = dataM.cumsum()
    cumsum.to_csv(file, mode='a', header=False)
    logger.debug_msg("----- Function End -----")


def linegraphall(csvindex):
    logger.debug_msg("----- Function Start -----")
    logger.app_logger.info("線グラフ")
    plt.rcParams["figure.figsize"] = [FIG_SIZE_X, FIG_SIZE_Y]

    csv = g_data_dir + "timesumtotal.csv"
    data = pd.read_csv(csv, header=0, engine='python')

    times = data['time']
    if not g_logwording1 == "":
        data1 = data[g_logwording1]
        plt.plot(times, data1, color=config.log_analyzer_color1, label=g_logwording1)
    if not g_logwording2 == "":
        data2 = data[g_logwording2]
        plt.plot(times, data2, color=config.log_analyzer_color2, label=g_logwording2)
    if not g_logwording3 == "":
        data3 = data[g_logwording3]
        plt.plot(times, data3, color=config.log_analyzer_color3, label=g_logwording3)
    if not g_logwording4 == "":
        data4 = data[g_logwording4]
        plt.plot(times, data4, color=config.log_analyzer_color4, label=g_logwording4)
    if not g_logwording5 == "":
        data5 = data[g_logwording5]
        plt.plot(times, data5, color=config.log_analyzer_color5, label=g_logwording5)

    plt.xticks(rotation=90)
    plt.rcParams['figure.subplot.bottom'] = 0.20
    plt.gca().get_yaxis().set_major_locator(MaxNLocator(integer=True))
    plt.xlabel("time", fontname = config.g_font)
    plt.ylabel("num", fontname = config.g_font, rotation = 0)
    plt.title("Total", fontname = config.g_font)
    bottom, top = plt.ylim()
    if top < 1:plt.ylim(top=1.05)
    plt.ylim(bottom=0)
    plt.legend()
    plt.grid(True)
    plt.savefig(g_data_dir + "linegraphall.png", bbox_inches='tight')
    if IMAGE_SHOW_ENABLE: plt.show()
    plt.close()
    plt.clf()
    logger.debug_msg("----- Function End -----")


def linegraph(csvindex):
    logger.debug_msg("----- Function Start -----")
    logger.app_logger.info("棒グラフ")
    plt.rcParams["figure.figsize"] = [FIG_SIZE_X, FIG_SIZE_Y]
    csv = g_data_dir + "timesumtotal.csv"
    data = pd.read_csv(csv, header=0, engine='python')
    if not g_logwording1 == "":make_linegraph(csvindex, data, g_logwording1, config.log_analyzer_color1, "1")
    if not g_logwording2 == "":make_linegraph(csvindex, data, g_logwording2, config.log_analyzer_color2, "2")
    if not g_logwording3 == "":make_linegraph(csvindex, data, g_logwording3, config.log_analyzer_color3, "3")
    if not g_logwording4 == "":make_linegraph(csvindex, data, g_logwording4, config.log_analyzer_color4, "4")
    if not g_logwording5 == "":make_linegraph(csvindex, data, g_logwording5, config.log_analyzer_color5, "5")
    logger.debug_msg("----- Function End -----")


def allgraph(csvindex):
    logger.debug_msg("----- Function Start -----")
    image01 = Image.open(g_data_dir + 'circlegraph.png')
    image02 = Image.open(g_data_dir + 'linegraphall.png')
    image03 = Image.open(g_data_dir + 'bargraph_CRITICAL.png')
    image04 = Image.open(g_data_dir + 'linegraph_CRITICAL.png')
    image05 = Image.open(g_data_dir + 'bargraph_ERROR.png')
    image06 = Image.open(g_data_dir + 'linegraph_ERROR.png')
    image07 = Image.open(g_data_dir + 'bargraph_WARNING.png')
    image08 = Image.open(g_data_dir + 'linegraph_WARNING.png')
    images = [image01, image02, image03, image04, image05, image06, image07, image08]

    fig = plt.figure()
    for i, im in enumerate(images):
        fig.add_subplot(4,2,i+1).set_title(str(i))
        plt.imshow(im)
    plt.savefig(g_data_dir + "allgraph.png", bbox_inches='tight')
    if IMAGE_SHOW_ENABLE: plt.show()
    plt.close()
    plt.clf()
    logger.debug_msg("----- Function End -----")


'''
https://qiita.com/ys_dirard/items/0bdd8437f78f67dfccc9
https://kino-code.com/python-matplotlib-add_subplot/
def allgraph(csvindex):
    csl.stdout_infotdout_infotdout_info("###########allgraph##############")
    plt.rcParams["figure.figsize"] = [FIG_SIZE_X, FIG_SIZE_Y]
    daysFmt = mdates.DateFormatter('%Y-%m-%d\n%H:%M:%S')
    #daysFmt = mdates.DateFormatter('%H:%M:%S')

    #plt.set_xticks(rotation=90)
    #plt.rcParams['figure.subplot.bottom'] = 0.20
    #plt.gca().get_yaxis().set_major_locator(MaxNLocator(integer=True))

    fig = plt.figure()
    #fig = plt.figure(figsize=[FIG_SIZE_X / 2, FIG_SIZE_Y / 4])

    if not g_logwording1 == "" and not g_logwording2 == "" and not g_logwording3 == "" :
        ax1 = fig.add_subplot(4, 2, 1)
        ax2 = fig.add_subplot(4, 2, 2)
        ax3 = fig.add_subplot(4, 2, 3)
        ax4 = fig.add_subplot(4, 2, 4)
        ax5 = fig.add_subplot(4, 2, 5)
        ax6 = fig.add_subplot(4, 2, 6)
        ax7 = fig.add_subplot(4, 2, 7)
        ax8 = fig.add_subplot(4, 2, 8)
    elif not g_logwording1 == "" and not g_logwording2 == "" and g_logwording3 == "" :
        ax1 = fig.add_subplot(3, 2, 1)
        ax2 = fig.add_subplot(3, 2, 2)
        ax3 = fig.add_subplot(3, 2, 3)
        ax4 = fig.add_subplot(3, 2, 4)
        ax5 = fig.add_subplot(3, 2, 5)
        ax6 = fig.add_subplot(3, 2, 6)
    elif not g_logwording1 == "" and g_logwording2 == "" and g_logwording3 == "" :
        ax1 = fig.add_subplot(2, 2, 1)
        ax2 = fig.add_subplot(2, 2, 2)
        ax3 = fig.add_subplot(2, 2, 3)
        ax4 = fig.add_subplot(2, 2, 4) 

    csv1 = g_data_dir + "total.csv"
    data1 = pd.read_csv(csv1, header=0, skipfooter=1, engine='python')
    pie_colors1 = [g_color0, g_color1, g_color2, g_color3, g_color4]

    #fig1, ax11 = plt.subplots()
    ax1.pie(data1['件数'], labels=g_labels, autopct='%1.1f%%', startangle=0, colors=pie_colors1)
    ax1.axis('equal')
    ax1.legend()
    ax1.set_title("ログレベル割合", fontname = 'MS Gothic')

    csl.stdout_info("#################################")
    csv2 = g_data_dir + "timecount.csv"
    data2 = pd.read_csv(csv2, header=0, skipfooter=0, engine='python')
    csl.stdout_info("-------------")
    csl.stdout_info(data2)

    #times2 = pd.to_datetime(data2['time'])#★横軸自動調整
    times2 = data2['time']
    if not g_logwording1 == "":
        data21 = data2[g_logwording1]
    if not g_logwording2 == "":
        data22 =  data2[g_logwording2]
    if not g_logwording3 == "":
        data23 =  data2[g_logwording3]

    if not g_logwording1 == "":
        bar1 = ax3.bar(times2, data21, width = 0.4, color="red", label=g_logwording1)
        #ax3.set_xticklabels(times2, rotation=90, ha='right')
        #ax3.set_xticks(rotation=90)
        #ax3.rcParams['figure.subplot.bottom'] = 0.20
        #ax3.gca().get_yaxis().set_major_locator(MaxNLocator(integer=True))
        ax3.set_xlabel("time", fontname = 'MS Gothic')
        ax3.set_ylabel("件数", fontname = 'MS Gothic', rotation = 0)
        ax3.set_title("時間あたり件数", fontname = 'MS Gothic')
        ax3.legend()
        y_min, y_max = ax3.get_ylim()
        if y_max < 1:
            ax3.set_ylim(0, 1.05)
        ax3.yaxis.set_major_locator(MaxNLocator(integer=True))
        ###ax3.xaxis.set_major_formatter(daysFmt)
        ax3.grid()

    if not g_logwording2 == "":
        bar2 = ax5.bar(times2, data22, width = 0.4, color="purple", label=g_logwording2)
        #ax5.xticks(rotation=90)
        #ax5.rcParams['figure.subplot.bottom'] = 0.20
        #ax5.gca().get_yaxis().set_major_locator(MaxNLocator(integer=True))
        ax5.set_xlabel("時間", fontname = 'MS Gothic')
        ax5.set_ylabel("件数", fontname = 'MS Gothic', rotation = 0)
        ax5.set_title("時間あたり件数", fontname = 'MS Gothic')
        ax5.legend()
        y_min, y_max = ax5.get_ylim()
        if y_max < 1:
            ax5.set_ylim(0, 1.05)
        ax5.yaxis.set_major_locator(MaxNLocator(integer=True))
        ###ax5.xaxis.set_major_formatter(daysFmt)
        ax5.grid()
        #ax5.savefig(g_data_dir + "bargraph2.png", bbox_inches='tight')
        #ax5.show()

    if not g_logwording3 == "":
        bar3 = ax7.bar(times2, data23, width = 0.4, color="yellow", label=g_logwording3)
        #ax7.xticks(rotation=90)
        #ax
        *************ない


csl.stdout_info("#################################")
    csv3 = g_data_dir + "timesumtotal.csv"

 

    data3 = pd.read_csv(csv3, header=0, engine='python')
    csl.stdout_info("-------------")
    csl.stdout_info(data3)
    times3 = data3['time']
    if not g_logwording1 == "":
        data31 = data3[g_logwording1]
    if not g_logwording2 == "":
        data32 =  data3[g_logwording2]
    if not g_logwording3 == "":
        data33 =  data3[g_logwording3]

    if not g_logwording1 == "":
        ax2.plot(times3, data31, color="red", label = g_logwording1)
    if not g_logwording2 == "":
        ax2.plot(times3, data32, color="purple", label = g_logwording2)
    if not g_logwording3 == "":
        ax2.plot(times3, data33, color="yellow", label = g_logwording3)
    ax2.set_xlabel("時間", fontname = 'MS Gothic')
    ax2.set_ylabel("件数", fontname = 'MS Gothic', rotation = 0)
    ax2.set_title("累計件数", fontname = 'MS Gothic')
    ax2.legend()
    y_min, y_max = ax2.get_ylim()
    if y_max < 1:
        ax2.set_ylim(0, 1.05)
    else:
        ax2.set_ylim(0, y_max)
    ax2.yaxis.set_major_locator(MaxNLocator(integer=True))
    #ax2.xaxis.set_major_formatter(daysFmt)
    ax2.grid()
    #ax7.savefig(g_data_dir + "bargraph3.png", bbox_inches='tight')

 

    csl.stdout_info("#################################")
    csv4 = g_data_dir + "timesumtotal.csv"

 

    data4 = pd.read_csv(csv4, header=0, engine='python')
    csl.stdout_info("-------------")
    csl.stdout_info(data4)
    times4 = data4['time']
    if not g_logwording1 == "":
        data41 = data4[g_logwording1]
    if not g_logwording2 == "":
        data42 = data4[g_logwording2]
    if not g_logwording3 == "":
        data43 = data4[g_logwording3]
    if not g_logwording1 == "":
        plot1 = ax4.plot(times4, data41, color="red", label=g_logwording1)
        ax4.set_xlabel("時間", fontname = 'MS Gothic')
        ax4.set_ylabel("件数", fontname = 'MS Gothic', rotation = 0)
        ax4.set_title("累計件数", fontname = 'MS Gothic')
        ax4.legend()
        y_min, y_max = ax4.get_ylim()
        if y_max < 1:
            ax4.set_ylim(0, 1.05)
        else:
            ax4.set_ylim(0, y_max)
        ax4.yaxis.set_major_locator(MaxNLocator(integer=True))
        #ax4.xaxis.set_major_formatter(daysFmt)
        ax4.grid()
        #plt.xticks(rotation=90)
        #plt.rcParams['figure.subplot.bottom'] = 0.20
        #plt.gca().get_yaxis().set_major_locator(MaxNLocator(integer=True))
        #lt.xlabel("時間", fontname = 'MS Gothic')
        #plt.ylabel("件数", fontname = 'MS Gothic', rotation = 0)
        #plt.savefig(g_data_dir + "linegraph1.png", bbox_inches='tight')
        #plt.show()

 

    if not g_logwording2 == "":
        plot2 = ax6.plot(times4, data42, color="purple", label=g_logwording2)
        ax6.set_xlabel("時間", fontname = 'MS Gothic')
        ax6.set_ylabel("件数", fontname = 'MS Gothic', rotation = 0)
        ax6.set_title("累計件数", fontname = 'MS Gothic')
        ax6.legend()
        y_min, y_max = ax6.get_ylim()
        if y_max < 1:
            ax6.set_ylim(0, 1.05)
        else:
            ax6.set_ylim(0, y_max)
        ax6.yaxis.set_major_locator(MaxNLocator(integer=True))
        #ax6.xaxis.set_major_formatter(daysFmt)
        ax6.grid()
        #plt.xticks(rotation=90)
        #plt.rcParams['figure.subplot.bottom'] = 0.20
        #plt.gca().get_yaxis().set_major_locator(MaxNLocator(integer=True))
        #plt.xlabel("時間", fontname = 'MS Gothic')
        #plt.ylabel("件数", fontname = 'MS Gothic', rotation = 0)
        #plt.savefig(g_data_dir + "linegraph2.png", bbox_inches='tight')
        #plt.show()

 

    if not g_logwording3 == "":
        plot3 = ax8.plot(times4, data43, color="yellow", label=g_logwording3)
        ax8.set_xlabel("時間", fontname = 'MS Gothic')
        ax8.set_ylabel("件数", fontname = 'MS Gothic', rotation = 0)
        ax8.set_title("累計件数", fontname = 'MS Gothic')
        ax8.legend()
        y_min, y_max = ax8.get_ylim()
        if y_max < 1:
            ax8.set_ylim(0, 1.05)
        else:
            ax8.set_ylim(0, y_max)
        ax8.yaxis.set_major_locator(MaxNLocator(integer=True))
        #ax8.xaxis.s

'''
