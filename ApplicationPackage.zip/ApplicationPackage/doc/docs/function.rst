function module
===============

.. automodule:: function
    :members:
    :undoc-members:
    :show-inheritance:
