# -*- coding: utf-8 -*-
"""
Created on Tue Apr 28 15:53:21 2020

@author: hashimoto
"""

import sys
import os
import configparser
import platform
import datetime
#import common.logger


INI_FILE = '../config/config.ini'
inifile = configparser.ConfigParser()
inifile.read(INI_FILE, 'UTF-8')
config_log = inifile.get('log', 'log')  # ログパラメータ取得

#import common.logger

def get_parameter(kind, section, item):
    #import common.logger as logger

    if kind == "int":
        parameter = inifile.getint(section, item)
    elif kind == "float":
        parameter = inifile.getfloat(section, item)
    elif kind == "boolean":
        parameter = inifile.getboolean(section, item)
    elif kind == "string":
        parameter = inifile.get(section, item)
    elif kind == "datetime":
        date_string = inifile.get(section, item)
        try:
            parameter = datetime.datetime.strptime(date_string, "%Y-%m-%d %H:%M:%S")
        except ValueError:
            parameter = None  # パースエラーの場合はNoneをセット
            #logger.error_msg("Datetime Parameter Error: Invalid date format")
    elif kind == "list":
        parameter_str = inifile.get(section, item)
        parameter = [item.strip() for item in parameter_str.split(',')]
    elif kind == "tuple":
        parameter_str = inifile.get(section, item)
        parameter = tuple(item.strip() for item in parameter_str.split(','))
    elif kind == "exp":
        parameter_str = inifile.get(section, item)
        try:
            parameter = float(parameter_str)
        except ValueError:
            parameter = None  # パースエラーの場合はNoneをセット
            #logger.error_msg("Exponent Parameter Error: Invalid float format")
    elif kind == "hex":
        parameter_str = inifile.get(section, item)
        try:
            parameter = int(parameter_str, 16)  # 16進数文字列を10進数の整数に変換
        except ValueError:
            parameter = None  # パースエラーの場合はNoneをセット
            #logger.error_msg("Hex Parameter Error: Invalid hex format")
    elif kind == "bin":
        parameter_str = inifile.get(section, item)
        try:
            parameter = int(parameter_str, 2)  # 2進数文字列を10進数の整数に変換
        except ValueError:
            parameter = None  # パースエラーの場合はNoneをセット
            #logger.error_msg("Binary Parameter Error: Invalid binary format")
    else:
        parameter = "parameter not found"
        #logger.critical_msg("Parameter Kind Error : " + kind)

    log_mesg = "[" + section + "]" + item + " : " + str(parameter)
    #logger.debug_msg(log_mesg)
    return parameter


def init():
    import common.logger as logger
    logger.debug_msg("----- Function Start -----")
    global g_font
    global g_cmd_clear
    os = platform.platform()  # OS情報取得

    # OS固有の情報設定
    if "Darwin" in os or "macOS" in os:  # MAC
        os_tmp = "Mac"
        g_font = graph_font_mac
        g_cmd_clear = command_clear_mac
    elif "Linux" in os:  # Linux
        os_tmp = "Linux"
        g_font = graph_font_lin
        g_cmd_clear = command_clear_lin
    elif "Win" in os:  # Windows
        os_tmp = "Windows"
        g_font = graph_font_win
        g_cmd_clear = command_clear_win
    else:
        logger.critical_msg("OS Type Error : " + os)

    logger.debug_msg("OS : " + os )
    logger.debug_msg("OS : " + os_tmp )
    logger.debug_msg("Font : " + g_font )
    logger.debug_msg("Clear Command : " + g_cmd_clear )
    logger.debug_msg("----- Function End -----")


def logging_paramter():
    import common.logger as logger
    logger.debug_msg("----- Function Start -----")
    logger.debug_msg("[config]log:%s", config_log)
    logger.debug_msg("[config]facility:%s", syslog_facility)
    logger.debug_msg("[config]option:%s", syslog_option)
    logger.debug_msg("----- Function End -----")


# パラメータ取得
try:
#    config_log = inifile.get('config', 'log')
    syslog_facility = inifile.get('syslog', 'facility')
    syslog_option = inifile.get('syslog', 'option')

    # DB
    # sqlite
    sqlite_db = get_parameter('string', 'sqlite', 'db')
    sqlite_create_tbl_ope = get_parameter('string', 'sqlite', 'create_tbl_ope')
    # mariadb
    mariadb_host = get_parameter('string', 'mariadb', 'host')
    mariadb_port = get_parameter('int', 'mariadb', 'port')
    mariadb_db = get_parameter('string', 'mariadb', 'db')
    mariadb_user = get_parameter('string', 'mariadb', 'user')
    mariadb_password = get_parameter('string', 'mariadb', 'password')
    # postgresql
    postgresql_host = get_parameter('string', 'postgresql', 'host')
    postgresql_port = get_parameter('int', 'postgresql', 'port')
    postgresql_name = get_parameter('string', 'postgresql', 'db')
    postgresql_user = get_parameter('string', 'postgresql', 'user')
    postgresql_password = get_parameter('string', 'postgresql', 'password')

    # Line
    line_notify_api = get_parameter('string', 'line', 'notify_api')
    line_notify_token = get_parameter('string', 'line', 'notify_token')

    # translation
    translation_language = get_parameter('string', 'translation', 'language')
    translation_dictionary_dir = get_parameter('string', 'translation', 'dictionary_dir')
    translation_dictionary_file = get_parameter('string', 'translation', 'dictionary_file')

    # command
    command_clear_mac = get_parameter('string', 'command', 'clear_mac')
    command_clear_win = get_parameter('string', 'command', 'clear_win')
    command_clear_lin = get_parameter('string', 'command', 'clear_lin')

    # time
    time_datetime = get_parameter('datetime', 'time', 'datetime')

    # function
    function_param_int = get_parameter('int', 'function', 'param_int')
    function_param_float = get_parameter('float', 'function', 'param_float')
    function_param_boolean = get_parameter('boolean', 'function', 'param_boolean')
    function_list_data = get_parameter('list', 'function', 'list_data')
    function_param_exp = get_parameter('exp', 'function', 'param_exp')
    function_param_hex = get_parameter('hex', 'function', 'param_hex')
    function_param_bin = get_parameter('bin', 'function', 'param_bin')
    function_tuple_data = get_parameter('tuple', 'function', 'tuple_data')

    # log analyzer
    log_analyzer_ini_file = get_parameter('string', 'log_analyzer', 'ini_file')
    log_analyzer_out_dir = get_parameter('string', 'log_analyzer', 'out_dir')
    log_analyzer_color1 = get_parameter('string', 'log_analyzer', 'color1')
    log_analyzer_color2 = get_parameter('string', 'log_analyzer', 'color2')
    log_analyzer_color3 = get_parameter('string', 'log_analyzer', 'color3')
    log_analyzer_color4 = get_parameter('string', 'log_analyzer', 'color4')
    log_analyzer_color5 = get_parameter('string', 'log_analyzer', 'color5')

    # graph
    graph_font_mac = get_parameter('string', 'graph', 'font_mac')
    graph_font_win = get_parameter('string', 'graph', 'font_win')
    graph_font_lin = get_parameter('string', 'graph', 'font_lin')
    graph_show_enable = get_parameter('boolean', 'graph', 'show_enable')

    # seq diagram
    seq_diagram_ini_file = get_parameter('string', 'seq_diagram', 'ini_file')
    seq_diagram_out_dir = get_parameter('string', 'seq_diagram', 'out_dir')

    # timechart
    timechart_ini_file = get_parameter('string', 'timechart', 'ini_file')
    timechart_out_dir = get_parameter('string', 'timechart', 'out_dir')
    timechart_mmd_fmt = get_parameter('string', 'timechart', 'mmd_fmt')
    timechart_dateFormat = get_parameter('string', 'timechart', 'dateFormat')
    #timechart_axisFormat = get_parameter('string', 'timechart', 'axisFormat')
    timechart_tickInterval = get_parameter('string', 'timechart', 'tickInterval')

except:
    import common.logger
    type, value, traceback = sys.exc_info()
    common.logger.critical_msg('Except:%s<%s>%s', type, value, traceback)
