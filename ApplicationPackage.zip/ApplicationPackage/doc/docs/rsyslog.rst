rsyslog module
==============

.. automodule:: rsyslog
    :members:
    :undoc-members:
    :show-inheritance:
