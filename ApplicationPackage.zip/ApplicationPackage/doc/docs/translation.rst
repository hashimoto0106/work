translation module
==================

.. automodule:: translation
    :members:
    :undoc-members:
    :show-inheritance:
