line module
===========

.. automodule:: line
    :members:
    :undoc-members:
    :show-inheritance:
