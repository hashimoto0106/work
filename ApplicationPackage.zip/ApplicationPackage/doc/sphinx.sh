sphinx-apidoc -F -o ./docs ../src
sphinx-build -a ./docs ./html