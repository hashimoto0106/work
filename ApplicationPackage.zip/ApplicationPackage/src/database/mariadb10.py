# -*- coding: utf-8 -*-
"""
Created on Wed Apr 29 18:36:30 2020

@author: sample
"""

import os
import sys
import mariadb
import platform
import config
from datetime import datetime
import time
import common.logger as logger
import version as app_ver
import common.timechart as timechart


class MariaDB(object):

    def table_exists(self, connection, table_name):
        try:
            with connection.cursor() as cursor:
                cursor.execute(
                    "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s",
                    (connection.database, table_name)
                )
                result = cursor.fetchone()
                return result[0] > 0  # テーブルが存在すればTrueを返す
        except mariadb.Error as e:
            type, value, traceback = sys.exc_info()
            logger.warning_msg('Except:%s<%s>%s', type, value, traceback)
            logger.warning_msg(f"Error checking if table exists: {e}")
            return False


    def __init__(self, host, port, database, user, password):
        #logger.debug_msg("----- Function Start -----")
        self.host = host
        self.port = port
        self.database = database
        self.user = user
        self.password = password
        #logger.debug_msg("----- Function End -----")


    def connect(self):
        logger.debug_msg("----- Function Start -----")
        logger.trace_msg("APP->>DB:Init")
        print("~~~~~~~~~~~~~~~~~~")
        try:
            '''
            if self.g_conn:
                print("if self.g_conn")
            elif not self.g_conn:
                print("elif not self.g_conn")
            else:
                print("else")
            '''
                
            #print(self.g_conn)
            #print("connection close")
            #self.g_conn.close()  # 古い接続を閉じる
            # Synplogy MariaDB コネクション取得
            self.g_conn = mariadb.connect(
                user = self.user,
                password = self.password,
                host = self.host,
                port = self.port,
                database = self.database
            )
            print(self.g_conn)
            print("Connection successful")

            if self.table_exists(self.g_conn, 'history'):
                pass
            else:
                logger.warning_msg("history table not found ")
                self.create_table()
        except mariadb.Error as e:
            print(f"Error connecting to MariaDB: {e}")
        except:
            type, value, traceback = sys.exc_info()
            print('Except:%s<%s>%s', type, value, traceback)
            logger.critical_msg('Except:%s<%s>%s', type, value, traceback)
            logger.trace_msg("DB-->>APP:error")

        logger.trace_msg("DB-->>APP:Success")
        logger.debug_msg("----- Function End -----")


    def create_table(self):
        logger.debug_msg("----- Function Start -----")
        logger.trace_msg("DB->>DB:Create Table")
        #delete_table()
        #time.sleep(2)  # テーブル削除待機

        # テーブル生成
        with self.g_conn:
            with self.g_conn.cursor() as cursor:
                # Create Table
                db_cmd = '''
                        CREATE TABLE `history` (
                            `id` int(11) NOT NULL AUTO_INCREMENT,
                            `start_time` DATETIME NOT NULL,
                            `app` varchar(64) COLLATE utf8_bin NOT NULL,
                            `os` varchar(64) COLLATE utf8_bin NOT NULL,
                            `python` varchar(64) COLLATE utf8_bin NOT NULL,
                            `host` varchar(64) COLLATE utf8_bin NOT NULL,
                            `proc_time_sec` FLOAT NOT NULL,
                            `comment` varchar(255) COLLATE utf8_bin NOT NULL,
                            PRIMARY KEY (`id`)
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
                        AUTO_INCREMENT=1;
                    '''
                cursor.execute(db_cmd)
                self.g_conn.commit()

                db_cmd = '''
                        CREATE TABLE `log` (
                            `time` DATETIME NOT NULL,
                            `level` varchar(64) COLLATE utf8_bin NOT NULL,
                            `message` varchar(64) COLLATE utf8_bin NOT NULL
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
                    '''
                cursor.execute(db_cmd)
                self.g_conn.commit()

        logger.trace_msg("DB-->>DB:Success")
        logger.debug_msg("----- Function End -----")


    def insert_history(self, start_time, proc_time, comment):
        logger.debug_msg("----- Function Start -----")
        logger.trace_msg("APP->>DB:Insert")
        start = datetime.now()
        start_time = start_time.replace(microsecond=0)  # マイクロ秒を切り捨て

        if not self.g_conn:  # 接続が無効なら再接続
            self.connect()
            print("-----接続無効------")
        if self.g_conn:  # 接続が成功した場合のみ実行
            try:
                with self.g_conn:
                    with self.g_conn.cursor() as cursor:
                        db_cmd = "INSERT INTO `history` (`start_time`, `app`, `os`, `python`, `host`, `proc_time_sec`, `comment`) VALUES (%s, %s, %s, %s, %s, %s, %s)"
                        cursor.execute(db_cmd, (start_time, app_ver.get(), platform.platform(),platform.python_version() ,platform.node() ,proc_time ,comment))
                    self.g_conn.commit()
                    #self.g_conn.close()  # コネクションを閉じる
            except:
                type, value, traceback = sys.exc_info()
                logger.critical_msg('Except:%s<%s>%s', type, value, traceback)
                logger.trace_msg("DB-->>APP:error")

        timechart.logging_md("DB", start, datetime.now())
        logger.trace_msg("DB-->>APP:Success")
        logger.debug_msg("----- Function End -----")


    def insert_log(self, level, message):
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        print(self.g_conn)
        if not self.g_conn:  # 接続が無効なら再接続
            self.connect()
            print("-----接続無効------")
        #if self.g_conn:  # 接続が成功した場合のみ実行
        else:
            try:
                self.connect()  # todo できれば削除したい
                with self.g_conn:
                    print("INSERT")
                    with self.g_conn.cursor() as cursor:
                        db_cmd = "INSERT INTO `log` (`time`, `level`, `message`) VALUES (%s, %s, %s)"
                        cursor.execute(db_cmd, (current_time, level, message))
                    self.g_conn.commit()
            except mariadb.ProgrammingError as e:
                type_, value, traceback = sys.exc_info()
                print(f"ProgrammingError: {e}")
                logger.critical_msg('Except:%s<%s>%s', type_, value, traceback)
            except mariadb.Error as e:
                type_, value, traceback = sys.exc_info()
                print(f"Database Error: {e}")
                logger.critical_msg('Except:%s<%s>%s', type_, value, traceback)
            except:
                type, value, traceback = sys.exc_info()
                logger.critical_msg('Except:%s<%s>%s', type, value, traceback)
                logger.trace_msg("DB-->>APP:error")


    def delete_table(self):
        logger.debug_msg("----- Function Start -----")
        logger.trace_msg("APP->>DB:Delete Table")
        with self.g_conn:
            with self.g_conn.cursor() as cursor:
                # テーブルが存在する場合は削除
                cursor.execute('DROP TABLE IF EXISTS history')
        logger.trace_msg("DB-->>APP:Success")
        logger.debug_msg("----- Function End -----")


    def reset_table(self):
        logger.debug_msg("----- Function Start -----")
        logger.trace_msg("APP->>DB:Reset Table")
        with self.g_conn:
            with self.g_conn.cursor() as cursor:
                # テーブルが存在する場合は削除
                cursor.execute('VACUUM')
        self.create_table()
        logger.trace_msg("DB-->>APP:Success")
        logger.debug_msg("----- Function End -----")


# グローバルインスタンス作成
g_db_mariadb = MariaDB(config.mariadb_host, config.mariadb_port, config.mariadb_db, config.mariadb_user, config.mariadb_password)
