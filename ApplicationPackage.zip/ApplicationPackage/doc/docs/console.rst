console module
==============

.. automodule:: console
    :members:
    :undoc-members:
    :show-inheritance:
