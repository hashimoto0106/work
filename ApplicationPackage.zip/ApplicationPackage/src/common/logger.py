# -*- coding: utf-8 -*-
"""
Created on Tue Apr 28 14:48:25 2020

@author: sample
"""

import logging.config
import config
import platform
from colorama import Fore, Back, Style
import common.console as console
import common.seq_diagram as seq
from database.mariadb10 import g_db_mariadb


# ログ設定ファイルからログ設定を読み込み
logging.config.fileConfig(config.config_log)
app_logger = logging.getLogger()


def init():
    debug_msg("----- Function Start -----")
    app_logger.info('logging Init')
    debug_msg("----- Function End -----")


def logging_environment():
    # 開発環境
    app_logger.info("Python Version:%s", platform.python_version())
    app_logger.info("Compiler:%s", platform.python_compiler())
    app_logger.info("Build:%s", str(platform.python_build()).replace(',',''))

    # オペレーティングシステム/ハードウェア情報
    app_logger.info("OS:%s", platform.platform())
    app_logger.info("uname:%s", str(platform.uname()).replace(',',''))
    app_logger.info("system:%s", platform.system())
    app_logger.info("node:%s", platform.node())
    app_logger.info("release:%s", platform.release())
    app_logger.info("version:%s", platform.version())
    app_logger.info("machine:%s", platform.machine())
    app_logger.info("architecture:%s", str(platform.architecture()).replace(',',''))
    app_logger.info("/bin/ls:%s", str(platform.architecture('/bin/ls')).replace(',',''))


def debug_msg(mesg, *args):
    formatted_message = mesg % args if args else mesg
    #colorized_message = formatted_message  # エスケープシーケンスがログに残ってしまう
    app_logger.debug(formatted_message)


def info_msg(mesg, *args):
    formatted_message = mesg % args if args else mesg
    colorized_message = Fore.BLUE + formatted_message + Style.RESET_ALL  # エスケープシーケンスがログに残ってしまう
    app_logger.info(formatted_message)


def warning_msg(mesg, *args):
    formatted_message = mesg % args if args else mesg
    #colorized_message = Fore.YELLOW + formatted_message + Style.RESET_ALL  # エスケープシーケンスがログに残ってしまう
    app_logger.warning(formatted_message)
    g_db_mariadb.insert_log("WARNING", formatted_message)


def error_msg(mesg, *args):
    formatted_message = mesg % args if args else mesg
    #colorized_message = Fore.MAGENTA + formatted_message + Style.RESET_ALL  # エスケープシーケンスがログに残ってしまう
    app_logger.error(formatted_message)
    g_db_mariadb.insert_log("ERROR", formatted_message)


def critical_msg(mesg, *args):
    formatted_message = mesg % args if args else mesg
    #colorized_message = Fore.RED + formatted_message + Style.RESET_ALL  # エスケープシーケンスがログに残ってしまう
    #app_logger.critical(formatted_message)
    #g_db_mariadb.insert_log("CRITICAL", formatted_message)


# TODO ; 引数 from, to, type, message
def trace_msg(mesg):
    app_logger.info(mesg)
    seq.logging_md(mesg)
