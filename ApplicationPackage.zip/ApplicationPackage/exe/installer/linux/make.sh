pyinstaller ../../src/main.py
