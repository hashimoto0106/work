# -*- coding: utf-8 -*-
"""
Created on Thu Jul 23 19:04:21 2020

@author: PC
"""

import numpy as np
import pandas as pd
import common.console as csl


def describe():
    df = pd.read_csv(g_dir+g_file, header=0)
#    csl.stdout_info(df)
    fw = open(g_dir+"analysis.csv", "w", encoding = "utf_8")
    fw.write("Item," + g_wd1 + "," + g_wd2 + "," + g_wd3 + "," + g_wd4 + "," + g_wd5 + "\n")
    fw.write("平均," + str(df[g_wd1].mean()) + "," + str(df[g_wd2].mean()) + "," + str(df[g_wd3].mean()) + "," + str(df[g_wd4].mean()) + "," + str(df[g_wd5].mean()) + "\n")
    fw.write("中央値," + str(df[g_wd1].median()) + "," + str(df[g_wd2].median()) + "," + str(df[g_wd3].median()) + "," + str(df[g_wd4].median()) + "," + str(df[g_wd5].median()) + "\n")
    fw.write("合計," + str(df[g_wd1].sum()) + "," + str(df[g_wd2].sum()) + "," + str(df[g_wd3].sum()) + "," + str(df[g_wd4].sum()) + "," + str(df[g_wd5].sum()) + "\n")
    fw.write("分散," + str(df[g_wd1].var(ddof=1)) + "," + str(df[g_wd2].var(ddof=1)) + "," + str(df[g_wd3].var(ddof=1)) + "," + str(df[g_wd4].var(ddof=1)) + "," + str(df[g_wd5].var(ddof=1)) + "\n")
    fw.write("標準偏差," + str(df[g_wd1].std(ddof=1)) + "," + str(df[g_wd2].std(ddof=1)) + "," + str(df[g_wd3].std(ddof=1)) + "," + str(df[g_wd4].std(ddof=1)) + "," + str(df[g_wd5].std(ddof=1)) + "\n")
    fw.write("最大," + str(df[g_wd1].max()) + "," + str(df[g_wd2].max()) + "," + str(df[g_wd3].max()) + "," + str(df[g_wd4].max()) + "," + str(df[g_wd5].max()) + "\n")
    fw.write("最小," + str(df[g_wd1].min()) + "," + str(df[g_wd2].min()) + "," + str(df[g_wd3].min()) + "," + str(df[g_wd4].min()) + "," + str(df[g_wd5].min()) + "\n")
    fw.write("歪度," + str(df[g_wd1].skew()) + "," + str(df[g_wd2].skew()) + "," + str(df[g_wd3].skew()) + "," + str(df[g_wd4].skew()) + "," + str(df[g_wd5].skew()) + "\n")
    fw.write("尖度," + str(df[g_wd1].kurt()) + "," + str(df[g_wd2].kurt()) + "," + str(df[g_wd3].kurt()) + "," + str(df[g_wd4].kurt()) + "," + str(df[g_wd5].kurt()) + "\n")
#    fw.write("四分位," + str(df[g_wd1].quantile(q=[0.25,0.75])) + "," + str(df[g_wd2].quantile(q=[0.25,0.75])) + "," + str(df[g_wd3].quantile(q=[0.25,0.75])) + "," + str(df[g_wd4].quantile(q=[0.25,0.75])) + "," + str(df[g_wd5].quantile(q=[0.25,0.75])) + "\n")
#    fw.write("最頻値," + str(df[g_wd1].mode()) + "," + str(df[g_wd2].mode()) + "," + str(df[g_wd3].mode()) + "," + str(df[g_wd4].mode()) + "," + str(df[g_wd5].mode()) + "\n")
    fw.close()


def get_feature_value(dir, file, wd1, wd2, wd3, wd4, wd5):
    global g_dir
    global g_file
    global g_wd1
    global g_wd2
    global g_wd3
    global g_wd4
    global g_wd5

    g_dir = dir
    g_file = file
    g_wd1 = wd1
    g_wd2 = wd2
    g_wd3 = wd3
    g_wd4 = wd4
    g_wd5 = wd5

    describe()

