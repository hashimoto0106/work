# -*- coding: utf-8 -*-
"""
Created on Wed Apr 29 18:36:30 2020

@author: sample
"""

import os
import sys
import sqlite3
import platform
import config
from datetime import datetime
import time
import common.logger as logger
import version as app_ver
import common.timechart as timechart


class sqlite(object):
    def __init__(self, db):
        logger.debug_msg("----- Function Start -----")
        logger.trace_msg("APP->>DB:Init")

        try:
            global g_conn
            g_conn = sqlite3.connect(db)  # dbファイルを開き、コネクションを取得

            global g_cursor
            g_cursor = g_conn.cursor()  # カーソルを取得

            if os.stat(db).st_size == 0:
                self.create_table()  # テーブル生成
        except:
            type, value, traceback = sys.exc_info()
            logger.critical_msg('Except:%s<%s>%s', type, value, traceback)
            logger.trace_msg("DB-->>APP:error")

        logger.trace_msg("DB-->>APP:Success")
        logger.debug_msg("----- Function End -----")


    def create_table(self):
        logger.debug_msg("----- Function Start -----")
        logger.trace_msg("DB->>DB:Create Table")
        #delete_table()
        #time.sleep(2)  # db生成待機

        # テーブル生成
        g_cursor.execute(config.sqlite_create_tbl_ope)
        logger.trace_msg("DB-->>DB:Success")
        logger.debug_msg("----- Function End -----")


    def insert(self, start_time, proc_time, comment):
        logger.debug_msg("----- Function Start -----")
        logger.trace_msg("APP->>DB:Insert")
        start = datetime.now()

        # マイクロ秒を切り捨て
        start_time = start_time.replace(microsecond=0)

        try:
            g_cursor.execute('INSERT INTO operation VALUES (:start_time, :app, :os, :python, :host, :proc_time_sec, :comment)',
            {'start_time': start_time, 'app': app_ver.get(), 'os': platform.platform(), 'python': platform.python_version(), 'host': platform.node(), 'proc_time_sec': proc_time, 'comment': comment})
        except:
            self.create_table()  # テーブル生成
            type, value, traceback = sys.exc_info()
            logger.critical_msg('Except:%s<%s>%s', type, value, traceback)
            logger.trace_msg("DB-->>APP:error")

        g_conn.commit()  # 変更をコミット（保存)
        g_conn.close()  # コネクションを閉じる
        timechart.logging_md("DB", start, datetime.now())
        logger.trace_msg("DB-->>APP:Success")
        logger.debug_msg("----- Function End -----")


    def delete_table(self):
        logger.debug_msg("----- Function Start -----")
        logger.trace_msg("APP->>DB:Delete Table")
        # テーブルが存在する場合は削除
        g_cursor.execute('DROP TABLE IF EXISTS operation')
        logger.trace_msg("DB-->>APP:Success")
        logger.debug_msg("----- Function End -----")


    def reset_table(self):
        logger.debug_msg("----- Function Start -----")
        logger.trace_msg("APP->>DB:Reset Table")
        self.delete_table()
        g_cursor.execute('VACUUM')
        self.create_table()
        logger.trace_msg("DB-->>APP:Success")
        logger.debug_msg("----- Function End -----")
