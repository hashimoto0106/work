# -*- coding: utf-8 -*-
"""
Created on Thu Feb 18 19:04:21 2024

@author: hashimoto
"""

import os, sys
import pandas as pd
import codecs
import glob
from datetime import datetime

import config
import common.logger as logger


def init():
    logger.debug_msg("----- Function Start -----")
    global g_mermaid_file
    g_mermaid_file = config.seq_diagram_out_dir + "seq_diagram.mmd"
    global g_f_md_org
    g_f_md_org = open(g_mermaid_file, "w", encoding="utf-8", newline="\n")
    # g_f_md_org.write("```mermaid\n")
    g_f_md_org.write("sequenceDiagram\n")
    # g_f_md_org.write("    actor User\n")
    # g_f_md_org.write("    participant APP\n")
    # g_f_md_org.write("    participant 初期化処理\n")
    # g_f_md_org.write("    participant 処理A\n")
    # g_f_md_org.write("    participant DB\n")
    logger.debug_msg("----- Function End -----")


def make_diagram(start_time=0, end_time=0):
    logger.debug_msg("----- Function Start -----")
    global setting
    setting = pd.read_csv(config.seq_diagram_ini_file, header=0, sep=",")
    lensetting = len(setting)

    for i in range(lensetting):
        logger.app_logger.info(setting.iloc[i, 0])
        if setting.iloc[i, 0].startswith('#'):continue  # コメントアウト
        get_param(i, start_time, end_time)
        preparation(i)
    logger.debug_msg("----- Function End -----")


def get_param(csvindex, start_time=0, end_time=0):
    logger.debug_msg("----- Function Start -----")
    global g_logitem
    global g_logfiles
    global g_starttimeY
    global g_starttimeH
    global g_endtimeY
    global g_endtimeH

    g_logitem = setting.iloc[csvindex, 0]
    g_logfiles = setting.iloc[csvindex, 1]

    if start_time == 0:
        g_starttimeY = setting.iloc[csvindex, 5]
        g_starttimeH = setting.iloc[csvindex, 6]
        g_endtimeY = setting.iloc[csvindex, 7]
        g_endtimeH = setting.iloc[csvindex, 8]
    else:
        g_starttimeY = start_time.strftime('%Y/%m/%d')
        g_starttimeH = start_time.strftime('%H:%M:%S.%f')
        g_endtimeY = end_time.strftime('%Y/%m/%d')
        g_endtimeH = end_time.strftime('%H:%M:%S.%f')

    logger.debug_msg(g_logitem)
    logger.debug_msg(g_logfiles)
    logger.debug_msg(g_starttimeY)
    logger.debug_msg(g_starttimeH)
    logger.debug_msg(g_endtimeY)
    logger.debug_msg(g_endtimeH)

    global g_data_dir
    g_data_dir = config.seq_diagram_out_dir + str(datetime.now().strftime('%Y%m%d')) + "_" + str(datetime.now().strftime('%H%M%S')) + "_" + g_logitem + "/"
    if not os.path.exists(g_data_dir): os.mkdir(g_data_dir)
    logger.debug_msg("----- Function End -----")


def preparation(csvindex):
    logger.debug_msg("----- Function Start -----")
    logger.app_logger.info("前処理")
    mermaid_file = g_data_dir + "seq_diagram.mmd"
    global g_f_md
    with open(mermaid_file, "w") as g_f_md:
        g_f_md.write("```mermaid\n")
        g_f_md.write("sequenceDiagram\n")
        g_f_md.write("    actor User\n")
        g_f_md.write("    participant APP\n")
        g_f_md.write("    participant 初期化処理\n")
        g_f_md.write("    participant 処理A\n")
        g_f_md.write("    participant DB\n")
        g_f_md.write("```\n")
    logger.debug_msg("----- Function End -----")


def logging_md(mesg):
    logger.debug_msg("----- Function Start -----")
    g_f_md_org.write("    " + mesg + "\n")
    logger.debug_msg("----- Function End -----")


def close():
    logger.debug_msg("----- Function Start -----")
    # g_f_md_org.write("```\n")
    g_f_md_org.close()

    # mmd -> pdf
    os.popen("mmdc --input " + g_mermaid_file + " --output " + config.seq_diagram_out_dir + "seq_diagram.pdf").readline().strip()
    os.popen("mmdc --input " + g_mermaid_file + " --output " + g_data_dir + "seq_diagram.pdf").readline().strip()
    logger.debug_msg("----- Function End -----")
