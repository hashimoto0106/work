class module
============

.. automodule:: class
    :members:
    :undoc-members:
    :show-inheritance:
