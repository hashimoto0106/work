# -*- coding: utf-8 -*-
"""
Created on Thu Jul 23 19:04:21 2020

@author: PC
"""

import common.console as csl

VERSION = "1.0.0"


def get():
    return VERSION


def show():
	csl.stdout_info("version:" + VERSION)
