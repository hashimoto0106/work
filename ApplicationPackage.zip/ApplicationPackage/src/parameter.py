# -*- coding: utf-8 -*-
"""
Created on Tue Apr 28 17:27:59 2020

@author: sample
"""

"""
PARAMETER1 float:
    explain

age string:
    explain

sex int:
    explain

"""
PARAMETER1 = 1.23456
PARAMETER2 = "abcdefg"
PARAMETER3 = 123456
