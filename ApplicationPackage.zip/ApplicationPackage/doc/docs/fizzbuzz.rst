fizzbuzz module
===============

.. automodule:: fizzbuzz
    :members:
    :undoc-members:
    :show-inheritance:
