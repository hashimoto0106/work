logger module
=============

.. automodule:: logger
    :members:
    :undoc-members:
    :show-inheritance:
