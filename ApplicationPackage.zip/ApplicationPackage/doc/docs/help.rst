help module
===========

.. automodule:: help
    :members:
    :undoc-members:
    :show-inheritance:
