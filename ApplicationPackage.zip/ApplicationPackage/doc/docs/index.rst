.. src documentation master file, created by
   sphinx-quickstart on Wed Apr 29 22:09:59 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to src's documentation!
===============================

Contents:

.. toctree::
   :maxdepth: 4

   class
   config
   database
   function
   help
   line
   logger
   main
   rsyslog


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

